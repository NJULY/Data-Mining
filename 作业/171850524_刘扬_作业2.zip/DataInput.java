import java.io.*;
import java.lang.reflect.Array;
import java.util.*;

// 处理输入数据, 将其构建成向量进行存储
public class DataInput {
    //public ArrayList<String> DB2 = new ArrayList<String>();

    public ArrayList<ArrayList<String>> getDB_csv(String fileRoad) {
        File csv = new File(fileRoad);
        ArrayList<ArrayList<String>> DB_csv = new ArrayList<ArrayList<String>>();
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(csv));
            String lineData = textFile.readLine();
            while((lineData = textFile.readLine()) != null) {
                DB_csv.add(getItemSet(lineData));
                //DB2.add(((lineData.split("\\{")[1]).split("\\}")[0]).replaceAll(",",";")+";");
            }
        } catch (FileNotFoundException e) {
            System.out.println("未找到指定文件!");
        } catch (IOException e) {
            System.out.println("文件读取出错!");
        }
        return DB_csv;
    }

    /*public ArrayList<ArrayList<String>> getDB_usage(String[] fileRoad) {
        ArrayList<ArrayList<String>> DB_usage = new ArrayList<ArrayList<String>>();
        for(int i = 0; i < fileRoad.length; i++) {
            File usage = new File(fileRoad[i]);
            ArrayList<String> itemSet = new ArrayList<String>();
            try {
                BufferedReader textFile = new BufferedReader(new FileReader(usage));
                String lineData = null;
                String cmd = null;
                while ((lineData = textFile.readLine()) != null) {
                    if (lineData.equals("**SOF**")) {
                        cmd = new String("");
                    } else if (lineData.equals("**EOF**")) {
                        if(!cmd.equals(""))
                            itemSet.add(cmd);
                    } else {
                        if (lineData.equals(";")) {
                            lineData = "#";
                        }
                        cmd += lineData;
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("未找到指定文件!");
            } catch (IOException e) {
                System.out.println("文件读取出错!");
            }
            Map<String, Integer> tmp = new HashMap<String, Integer>();
            for(String item : itemSet)
                tmp.put(item, 1);
            itemSet = new ArrayList<String>();
            for(String item : tmp.keySet())
                itemSet.add(item);
            DB_usage.add(itemSet);
        }
        return DB_usage;
    }*/

    public ArrayList<ArrayList<String>> getDB_usage(String[] fileRoad) {
        Map<String, Integer> count = new HashMap<String, Integer>();
        ArrayList<ArrayList<String>> DB_usage = new ArrayList<ArrayList<String>>();
        for(int i = 0; i < fileRoad.length; i++) {
            File usage = new File(fileRoad[i]);
            try {
                BufferedReader textFile = new BufferedReader(new FileReader(usage));
                String lineData = null;
                Map<String, Integer> itemSet = null;
                while ((lineData = textFile.readLine()) != null) {
                    if (lineData.equals("**SOF**")) {
                        itemSet = new HashMap<String, Integer>();
                    }
                    else if (lineData.equals("**EOF**")) {
                        if(itemSet.size() != 0) {
                            ArrayList<String> tmp = new ArrayList<String>();
                            for(String item : itemSet.keySet())
                                tmp.add(item);
                            DB_usage.add(tmp);
                        }
                    }
                    else {
                        if (lineData.equals(";")) {
                            itemSet.put("#",0);
                            count.put("#",0);
                        }
                        else {
                            String tmp = lineData;
                            itemSet.put(tmp, 0);
                            count.put(tmp,0);
                        }
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("未找到指定文件!");
            } catch (IOException e) {
                System.out.println("文件读取出错!");
            }
        }
        System.out.println("项数"+count.size());
        return DB_usage;
    }

    private ArrayList<String> getItemSet(String itemSet) {
        itemSet = itemSet.split("\\{")[1];
        itemSet = itemSet.split("\\}")[0];
        String[] items = itemSet.split(",");
        Collections.sort(Arrays.asList(items));
        ArrayList<String> res = new ArrayList<String>();
        for(String i : items)
            res.add(i);
        return res;
    }

    public static void cheakConsistency(String fileRoad1, String fileRoad2) {
        File file1 = new File(fileRoad1);
        File file2 = new File(fileRoad2);
        try {
            BufferedReader textFile1 = new BufferedReader(new FileReader(file1));
            BufferedReader textFile2 = new BufferedReader(new FileReader(file2));
            String lineData1, lineData2;
            while((lineData1 = textFile1.readLine()) != null && (lineData2 = textFile2.readLine()) != null) {
                if(!lineData1.equals(lineData2)) {
                    System.out.println("不一致");
                    System.out.println(lineData1);
                    System.out.println(lineData2);
                }
            }
            System.out.println("一致");
        } catch (FileNotFoundException e) {
            System.out.println("未找到指定文件!");
        } catch (IOException e) {
            System.out.println("文件读取出错!");
        }
    }

}
