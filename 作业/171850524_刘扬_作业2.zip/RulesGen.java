import java.util.*;

public class RulesGen {
    private double min_conf;
    private int transNum;
    private ArrayList<String> subSet, comSet; // 子集与对应补集

    public RulesGen(double conf, int numOfTrans) {
        min_conf = conf;
        transNum = numOfTrans;
        subSet = new ArrayList<String>();
        comSet = new ArrayList<String>();
    }

    // 求所有子集, 同时产生对应补集
    private void subSetGen(String itemSet) {
        subSet.clear();
        comSet.clear();
        String[] items = itemSet.split(";");
        // n元素集合共有2^n个子集
        long max = (int)(Math.pow(2, items.length)) - 1;
        // 用n位二进制数代表一个子集, 去除两个平凡子集, 0代表空集, max代表全集
        // 缺陷: 当频繁集项数超过63时无法使用
        for(long i = 1; i < max; i++) {
            String subset = "";
            String comset = "";
            long tmp1 = i;
            for(int j = 0; j < items.length; j++) {
                long tmp2 = tmp1 % 2;
                if(tmp2 == 1) {
                    if(subset.equals(""))
                        subset = items[j];
                    else
                        subset = subset + ";" + items[j];
                }
                else {
                    if(comset.equals(""))
                        comset = items[j];
                    else
                        comset = comset + ";" + items[j];
                }
                tmp1 = tmp1 /2;
            }
            subSet.add(subset);
            comSet.add(comset);
        }
    }

    private Map<String, Integer> sortL(Map<String, Integer> L) {
        Map<String, Integer> res = new HashMap<String, Integer>();

        for(Map.Entry<String, Integer> i : L.entrySet()) {
            String[] items = i.getKey().split(";");
            Collections.sort(Arrays.asList(items));
            String itemSet = "";
            for(String j : items) {
                if (itemSet.equals(""))
                    itemSet = j;
                else
                    itemSet = itemSet + ";" + j;
            }
            res.put(itemSet, i.getValue());
        }
        return res;
    }


    // 根据频繁项集和最小置信度生成关联规则
    public Map<String, String> rulesGen(Map<String, Integer> L) {
        Map<String, String> rules = new HashMap<String, String>();
        L = sortL(L);
        for(Map.Entry<String, Integer> entry : L.entrySet()) {
            String set = entry.getKey();
            subSetGen(set);
            if(!subSet.isEmpty()) {
                int size = subSet.size();
                for(int i = 0; i < size; i++) {
                    String subset = subSet.get(i);
                    String comset = comSet.get(i);
                    if(L.get(subset) != null) {
                        //double sup = (double)L.get(set) / transNum;
                        int sup = L.get(set);
                        Double conf = (double) L.get(set) / (double) L.get(subset);
                        if (conf >= min_conf) {
                            String[] tmp1 = subset.split(";");
                            String[] tmp2 = comset.split(";");
                            Collections.sort(Arrays.asList(tmp1));
                            Collections.sort(Arrays.asList(tmp2));
                            String ans1 = "", ans2 = "";
                            for(String sub1 : tmp1) {
                                if(ans1.equals(""))
                                    ans1 = sub1;
                                else
                                    ans1 = ans1 +";"+sub1;
                            }
                            for(String com1 : tmp2) {
                                if(ans2.equals(""))
                                    ans2 = com1;
                                else
                                    ans2 = ans2 +";"+com1;
                            }
                            rules.put(ans1 + " => " + ans2, String.format("[support=%d/%d;confidence=%.2f]", sup, transNum, conf));
                        }
                    }
                }
            }
        }
        return rules;
    }

}
