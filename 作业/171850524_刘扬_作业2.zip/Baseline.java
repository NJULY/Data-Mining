import java.util.*;

public class Baseline {
    private int min_sup;
    private ArrayList<ArrayList<String>> DB;
    private Map<String, Integer> L;

    public Baseline(ArrayList<ArrayList<String>> inputDB, int sup) {
        DB = inputDB;
        min_sup = sup;
        L = new HashMap<String, Integer>();
    }

    /* 基线算法的思路
    *  先筛选频繁项, 利用频繁项穷举频繁候选集
     */

    //先得到频繁1项集
    private Map<String, Integer> findL1() {
        Map<String, Integer> C1 = new HashMap<>();
        for(ArrayList<String> itemset : DB) {
            for(String item : itemset) {
                if(C1.get(item) == null)
                    C1.put(item, 1);
                else
                    C1.put(item, C1.get(item)+1);
            }
        }
        Map<String, Integer> L1 = new HashMap<>();
        for(Map.Entry<String, Integer> entry : C1.entrySet()) {
            if(entry.getValue() >= min_sup)
                L1.put(entry.getKey(), entry.getValue());
        }
        return L1;
    }

    /*private void freqSetGen(int[] arr, int index) {
        if(index == 0) { // 初始
            for(int i = 0; i < L1list.length; i++) {
                arr[index] = i;
                freqSetGen(arr, index+1);
            }
        }
        else if(index == max) { //终止
            return;
        }
        else { //递归
            int last = arr[index-1];
            for(int i = last+1; i < L1list.length; i++) {
                arr[index] = i;
                String itemSet = L1list[arr[0]];
                for(int j = 1; j <= index; j++) {
                    itemSet = itemSet + ";" + L1list[arr[j]];
                }
                int cnt = countCandiate(itemSet);
                if( cnt >= min_sup)
                    L.put(itemSet, cnt);
                freqSetGen(arr, index+1);
            }
        }
    }*/

    private Map<String, Integer> freqSetGen(Map<String, Integer> L1, Map<String, Integer> Lpre) {
        Map<String, Integer> Lk = new HashMap<String, Integer>();
        for(String l1 : L1.keySet()) {
            for(String lpre : Lpre.keySet()) {
                //利用L1与Lk-1组合产生Lk的候选集
                if(lpre.indexOf(l1) < 0) {
                    String[] items1 = lpre.split(";");
                    String[] items2 = new String[items1.length+1];
                    for(int i = 0; i < items1.length; i++)
                        items2[i] = items1[i];
                    items2[items2.length-1] = l1;
                    Collections.sort(Arrays.asList(items2));
                    int count = countCandiate(items2);
                    String key = "";
                    for(String item : items2) {
                        if(key.equals(""))
                            key = item;
                        else
                            key = key+";"+item;
                    }
                    //遍历数据库, 对候选项集支持度进行计数, 筛选出频繁项集
                    if(count >= min_sup && Lk.get(key) == null)
                        Lk.put(key, count);
                }
            }
        }
        return Lk;
    }

    private int countCandiate(String[] items) {
        int cnt = 0;
        for(ArrayList<String> trans : DB) {
            if(trans.containsAll(Arrays.asList(items))) {
                cnt++;
            }
        }
        return cnt;
    }

    public void baseline() {
        //寻找频繁1项集
        Map<String, Integer> L1 = findL1();
        //将频繁1项集加入最终的频繁项集L
        for(Map.Entry<String, Integer> entry : L1.entrySet()) {
            L.put(entry.getKey(), entry.getValue());
        }
        Map<String, Integer> Lpre = L1;
        //在Lk-1不为空的情况下, 循环生成Lk
        while(Lpre != null && Lpre.size() > 0) {
            Map<String, Integer> Lk = freqSetGen(L1, Lpre);
            //将产生的Lk加入最终的频繁项集L
            for(Map.Entry<String, Integer> entry : Lk.entrySet()) {
                L.put(entry.getKey(), entry.getValue());
            }
            Lpre = Lk;
        }
    }

    public Map<String, Integer> getFrequentItemSet() { return L;}
}
