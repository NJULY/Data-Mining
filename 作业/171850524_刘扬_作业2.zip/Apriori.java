import java.util.*;

/* 思路
将一个事务视为一个ArrayList<String>
数据库可以视为ArrayList<ArrayList<String>>
将所有的频繁项集存储在hashMap中
hashMap以String为key, 需要把ArrayList<String>连接成一个String作为key
 */
public class Apriori {
    private ArrayList<ArrayList<String>> DB;
    private int min_sup;
    private Map<String, Integer> L;
    private ArrayList<String> subSet, comSet; // 子集与对应补集

    public Apriori(ArrayList<ArrayList<String>> inputDB, int input_sup) {
        DB = inputDB;
        min_sup = input_sup;
        L = new HashMap<String, Integer>();
        subSet = new ArrayList<String>();
        comSet = new ArrayList<String>();
    }

    // 产生频繁1项集
    private Map<String, Integer> findL1() {
        Map<String, Integer> C1 = new HashMap<>();

        for(ArrayList<String> itemset : DB) {
            for(String item : itemset) {
                if(C1.get(item) == null)
                    C1.put(item, 1);
                else
                    C1.put(item, C1.get(item)+1);
            }
        }
        Map<String, Integer> L1 = new HashMap<>();
        for(Map.Entry<String, Integer> entry : C1.entrySet()) {
            if(entry.getValue() >= min_sup)
                L1.put(entry.getKey(), entry.getValue());
        }
        return L1;
    }

    // 判断频繁候选c是否频繁
    private boolean hasInfrequentSubset(String c, Map<String, Integer> Lpre) {
        String[] set = c.split(";");
        // 检查所有的k-1子集是否频繁
        for(int i = 0; i < set.length; i++) {
            String sub = "";
            for(int j = 0; j < set.length; j++) {
                if(j!=i) {
                    if(sub.equals(""))
                        sub = set[j];
                    else
                        sub = sub + ";" +set[j];
                }
            }
            if(Lpre.get(sub) == null)
                return true;
        }
        return false;
    }

    // 由Lk-1产生Ck
    private Map<String, Integer> aprioriGen(Map<String, Integer> Lpre) {
        Map<String, Integer> Ck = new HashMap<>();
        Set<Map.Entry<String, Integer>> LpreSet =  Lpre.entrySet();
        // 遍历Lk-1中的每一项, 生成候选频繁c
        for(Map.Entry<String, Integer> entry1 : LpreSet) {
            String[] set1 = entry1.getKey().split(";");
            for(Map.Entry<String, Integer> entry2 : LpreSet) {
                String[] set2 = entry2.getKey().split(";");
                boolean flag = true;
                for(int i = 0; i < set1.length-1; i++) {
                    if(set1[i].equals(set2[i]))
                        continue;
                    else {
                        flag = false;
                        break;
                    }
                }
                if(flag == true && set1[set1.length-1].compareTo(set2[set2.length-1]) < 0 ) {
                    String c = entry1.getKey();
                    c = c + ";" + set2[set2.length-1];
                    if(!hasInfrequentSubset(c, Lpre))
                        Ck.put(c, 0);
                }
            }
        }
        return Ck;
    }

    // Apriori的主要算法, 由DB产生频繁项集
    public void apriori() {
        Map<String, Integer> L1 = findL1();
        L.putAll(L1); //得到L1
        Map<String, Integer> Lpre = new HashMap<String, Integer>();
        Lpre.putAll(L1);
        // Lk-1不为空时, 循环继续
        while(Lpre != null && Lpre.size() > 0) {
            Map<String, Integer> C = aprioriGen(Lpre);// 由Lk-1计算得到Ck
            Set<String> itemSet = C.keySet();// 遍历DB, 对Ck中的项集进行计数
            for(ArrayList<String> t : DB) {//对DB中每一个事务
                for(String c : itemSet) {//对Ck中每一个频繁候选集c
                    String[] items = c.split(";");
                   if(t.containsAll(Arrays.asList(items))) {
                       C.put(c, C.get(c)+1);
                   }
                }
            }
            Lpre.clear();//更新Lpre
            for(String c : itemSet) {
                int sup = C.get(c);
                if(sup >= min_sup)
                    Lpre.put(c, sup);
            }
            L.putAll(Lpre);//更新L
        }
    }

    public Map<String, Integer> getFrequentItemSet() {
        return L;
    }

    // 针对一个频繁项集, 产生它的非空子集和对应补集
    private void subSetGen(String itemSet) {
        subSet.clear();
        comSet.clear();
        String[] items = itemSet.split(";");
        // n元素集合共有2^n个子集
        long max = (int)(Math.pow(2, items.length)) - 1;
        // 用n位二进制数代表一个子集, 去除两个平凡子集, 0代表空集, max代表全集
        // 缺陷: 当频繁集项数超过63时无法使用
        for(long i = 1; i < max; i++) {
            String subset = "";
            String comset = "";
            long tmp1 = i;
            for(int j = 0; j < items.length; j++) {
                long tmp2 = tmp1 % 2;
                if(tmp2 == 1) {
                    if(subset.equals(""))
                        subset = items[j];
                    else
                        subset = subset + ";" + items[j];
                }
                else {
                    if(comset.equals(""))
                        comset = items[j];
                    else
                        comset = comset + ";" + items[j];
                }
                tmp1 = tmp1 /2;
            }
            subSet.add(subset);
            comSet.add(comset);
        }
    }

    // 依据频繁项集产生关联规则
    public Map<String, Double> rulesGen() {
        Map<String, Double> rules = new HashMap<String, Double>();

        for(Map.Entry<String, Integer> entry : L.entrySet()) {
            String set = entry.getKey();
            subSetGen(set);
            if(!subSet.isEmpty()) {
                int size = subSet.size();
                for(int i = 0; i < size; i++) {
                    String subset = subSet.get(i);
                    String comset = comSet.get(i);
                    if(L.get(subset) != null) {
                        Double conf = (double)L.get(set) / (double)L.get(subset);
                        //if(conf >= min_conf)
                           // rules.put(subset+" -> " + comset, conf);
                    }
                }
            }
        }
        return rules;
    }
}
