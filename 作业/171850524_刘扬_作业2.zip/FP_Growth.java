import sun.reflect.generics.tree.Tree;

import java.util.*;

public class FP_Growth {
    private int min_sup;
    ArrayList<ArrayList<String>> DB;
    Map<String, Integer> L;
    boolean inputL1;

    //ArrayList<ArrayList<String>> DBnew = new ArrayList<ArrayList<String>>();

    // 构造FPtree
    public FP_Growth(ArrayList<ArrayList<String>> inputDB, int sup) {
        min_sup = sup;
        DB = inputDB;
        L= new HashMap<String, Integer>();
        inputL1 = false;
    }

    // 寻找频繁项集合
    private Map<String, TreeNode> findL() {
        Map<String, TreeNode> headList = new HashMap<String, TreeNode>();
        Map<String, Integer> C = new HashMap<String ,Integer>();
        // 遍历数据库, 将所有数据存放在hash表中
        for(ArrayList<String> i : DB) {
            for(String j : i) {
                if(C.get(j) == null)
                    C.put(j, 1);
                else
                    C.put(j, C.get(j)+1);
            }
        }
        for(Map.Entry<String, Integer> entry : C.entrySet()) {
            if(entry.getValue() >= min_sup)
                headList.put(entry.getKey(), new TreeNode(entry.getKey(), entry.getValue()));
        }
        //System.out.println("L1大小"+headList.size());
        return headList;
    }

    // 对于DB中每一个记录, 选择频繁项并按计数降序排序
    private String[] sortedTrans(ArrayList<String> trans, Map<String, TreeNode> headList, ItemCmp cmp) {
        ArrayList<String> freqItems = new ArrayList<String>();
        for(String i : trans) {
            if (headList.get(i) != null)
                freqItems.add(i);
        }
        String[] res = (String[]) freqItems.toArray(new String[freqItems.size()]);
        Arrays.sort(res, 0, freqItems.size(), cmp);
        return res;
    }

    // 将一条trans插入树中
    // 每次修改String[]花销大, 使用index表示待插入的item的下标
    private void insert_tree(TreeNode root, String[] items, int index, Map<String, TreeNode> headList) {
        if(index >= items.length) // 插入结束, 递归结束
            return;
        String item = items[index];
        // root没有子结点
        if(root.children == null) {
            root.children = new HashMap<String, TreeNode>();
        }
        TreeNode node = root.children.get(item);
        if(node == null) {
            // 新建结点
            node = new TreeNode(item, 1);
            node.parent = root;
            root.children.put(item, node);
            TreeNode p = headList.get(item);
            while(p.next != null)
                p = p.next;
            p.next = node;
        }
        else {
            // 已有结点, 更新信息
            node.count++;
            root.children.put(item, node);
        }
        insert_tree(node, items, index+1, headList);
    }

    // 构建FPtree
    private TreeNode makeFPtree(Map<String, TreeNode> headList) {
        TreeNode root = new TreeNode("null", 0);
        ItemCmp cmp = new ItemCmp(headList);
        for(ArrayList<String> trans : DB) {
            String[] items = sortedTrans(trans, headList, cmp);
            insert_tree(root, items, 0, headList);
        }
        return root;
    }

    // 得到headList排序数组
    private TreeNode[] makeHeadList(Map<String, TreeNode> headList) {
        TreeNode[] res = new TreeNode[headList.size()];
        int i = 0;
        for(Map.Entry<String, TreeNode> entry : headList.entrySet()) {
            res[i] = entry.getValue();
            i++;
        }
        Arrays.sort(res, 0, res.length, new HeadCmp());
        return res;
    }

    // 判断FPtree是否只包括一条路径
    private boolean isRoad(TreeNode root) {
        while(root.children != null) {
            if(root.children.size() == 1)
                root = root.children.get(0);
            else
                return false;
        }
        return true;
    }

    // 寻找条件模式基
    private Stack<String> findConditionalPatternBase(TreeNode leaf) {
        Stack<String> stack = new Stack<String>();
        TreeNode p = leaf.parent;
        while(!p.item.equals("null")) {
            stack.push(p.item);
            p = p.parent;
        }
        return stack;
    }

    // 根据FPtree挖掘频繁模式
    public void FP_growth(String pattern) {
        Map<String, TreeNode> headList = findL();
        TreeNode root = makeFPtree(headList);
        if(root.children == null)
            return;
        TreeNode[] list = makeHeadList(headList);
        if(!inputL1) {
            inputL1 = true;
            for(TreeNode node : list)
                L.put(node.item, node.count);
        }

        if(!pattern.equals("")) {
            for(int i = list.length - 1; i >= 0; i--) {
                TreeNode p =list[i];
                L.put(list[i].item+";"+pattern, list[i].count);
            }
        }

        // 对头表中的每一项, 构造条件模式基, 并递归挖掘
        for(int i = list.length - 1; i >= 0; i--) {
            String newPattern = "";
            ArrayList<ArrayList<String>> DBnew = new ArrayList<ArrayList<String>>();
           // DBnew.clear();
            TreeNode p = list[i];
            if(pattern.equals(""))
                newPattern = p.item;
            else
                newPattern = p.item+";"+pattern;
            while(p.next != null) {
                p = p.next;
                int cnt = p.count;
                for(int j = 0; j < cnt; j++) {
                    ArrayList<String> trans = new ArrayList<String>();
                    Stack<String> stack = findConditionalPatternBase(p);
                    while (!stack.isEmpty()) {
                        trans.add(stack.pop());
                    }
                    DBnew.add(trans);
                }
            }
            DB = DBnew;
            FP_growth(newPattern);
        }
    }

    public Map<String, Integer> getFrequentItemSet() {
        return L;
    }

}

class TreeNode {
    /* FP树结点需要包含的信息有:
     * 项名, 计数, 父指针, 子指针, 链表指针
     * 是一棵包含链表的多叉树
    */
    public String item;
    public int count;
    public TreeNode parent;
    public Map<String, TreeNode> children;
    public TreeNode next;

    public TreeNode(String itemName, int cnt) {
        item = itemName;
        count = cnt;
        parent = null;
        children = null;
        next =null;
    }
}

class ItemCmp implements Comparator<String> {
    private Map<String, TreeNode> headList;
    public ItemCmp(Map<String, TreeNode> list) { headList = list;}
    public int compare(String a, String b) {
        int cnt1 = headList.get(a).count;
        int cnt2 = headList.get(b).count;
        if(cnt1 > cnt2)
            return -1;
        else if(cnt1 < cnt2)
            return 1;
        else {
            if(a.compareTo(b) < 0)
                return -1;
            else if(a.compareTo(b) == 0)
                return 0;
            else
                return 1;
        }
    }
}

class HeadCmp implements Comparator<TreeNode> {
    public HeadCmp() {}
    public int compare(TreeNode a, TreeNode b) {
        int cnt1 = a.count;
        int cnt2 = b.count;
        if(cnt1 > cnt2)
            return -1;
        else if(cnt1 < cnt2)
            return 1;
        else {
            if(a.item.compareTo(b.item) < 0)
                return -1;
            else if(a.item.compareTo(b.item) == 0)
                return 0;
            else
                return 1;
        }
    }
}