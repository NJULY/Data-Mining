import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.ArrayList;
import java.util.Map;
import java.lang.management.ManagementFactory;
import com.sun.management.OperatingSystemMXBean;
import java.util.Set;

public class Assignment2 {
    public static void main(String[] args) throws Exception {
        DataInput data1 = new DataInput();
        //ArrayList<ArrayList<String>> DB = data1.getDB_csv("Groceries.csv");
        String[] fileRoad = new String[9];
        for (int i = 0; i < 9; i++)
            fileRoad[i] = "usage/user" + i + ".txt";
        ArrayList<ArrayList<String>> DB = data1.getDB_usage(fileRoad);

        int sup = 1000;
        double conf = 0.90;
        long startTime, endTime;

        Baseline algorithm0 = new Baseline(DB, sup);
        Apriori algorithm1 = new Apriori(DB, sup);
        FP_Growth algorithm2 = new FP_Growth(DB, sup);
        RulesGen rulesGenerator = new RulesGen(conf, DB.size());

        //Thread.sleep(10000);

        /*startTime = System.currentTimeMillis();
        algorithm0.baseline();
        System.out.println("Baseline 频繁集个数: " + algorithm0.getFrequentItemSet().size());
        endTime = System.currentTimeMillis();
        System.out.println("耗时:" + (double) (endTime - startTime) / 1000.0 + "s");*/

        startTime = System.currentTimeMillis();
        algorithm1.apriori();
        System.out.println("Apriori 频繁集个数: " + algorithm1.getFrequentItemSet().size());
        endTime = System.currentTimeMillis();
        System.out.println("耗时:" + (double) (endTime - startTime) / 1000.0 + "s");

        startTime = System.currentTimeMillis();
        algorithm2.FP_growth("");
        System.out.println("FP_Growth 频繁集个数: " + algorithm2.getFrequentItemSet().size());
        endTime = System.currentTimeMillis();
        System.out.println("耗时:" + (double) (endTime - startTime) / 1000.0 + "s");

        //Map<String, String> rules0 = rulesGenerator.rulesGen(algorithm0.getFrequentItemSet());
        //System.out.println("Baseline 关联规则个数: "+rules0.size());
        Map<String, String> rules1 = rulesGenerator.rulesGen(algorithm1.getFrequentItemSet());
        System.out.println("Apriori 关联规则个数: "+rules1.size());
        Map<String, String> rules2 = rulesGenerator.rulesGen(algorithm2.getFrequentItemSet());
        System.out.println("FP_Growth 关联规则个数: "+rules2.size());


        //DataOutput.writeResult("Baseline.txt", rules0);
        DataOutput.writeResult("Apriori.txt", rules1);
        DataOutput.writeResult("FP_Growth.txt", rules2);

        //DataOutput.writeFrequentSet("set0.txt", algorithm0.getFrequentItemSet());
        DataOutput.writeFrequentSet("set1.txt", algorithm1.getFrequentItemSet());
        DataOutput.writeFrequentSet("set2.txt", algorithm2.getFrequentItemSet());

    }
}
