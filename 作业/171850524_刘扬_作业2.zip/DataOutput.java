import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

public class DataOutput {
    public static void writeResult(String fileRoad, Map<String, String> res) {
        try {
            File writer1 = new File(fileRoad);
            writer1.createNewFile();
            BufferedWriter out1 = new BufferedWriter(new FileWriter(writer1));

            String[] rules = new String[res.size()];
            int i = 0;
            for(Map.Entry<String, String> entry : res.entrySet()) {
                rules[i] = entry.getKey()+entry.getValue();
                i++;
            }
            Collections.sort(Arrays.asList(rules));
            for(i = 0; i < rules.length; i++)
                out1.write(rules[i]+"\n");
            out1.flush();
            out1.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeFrequentSet(String fileRoad, Map<String, Integer> set) {
        try {
            File writer1 = new File(fileRoad);
            writer1.createNewFile();
            BufferedWriter out1 = new BufferedWriter(new FileWriter(writer1));

            String[] res = new String[set.size()];
            int cnt = 0;
            for(Map.Entry<String, Integer> i : set.entrySet()) {
                String[] items = i.getKey().split(";");
                Collections.sort(Arrays.asList(items));
                String itemSet = "";
                for(String j : items)
                    itemSet = itemSet + j +";";
                itemSet = itemSet+"sup="+i.getValue().toString();
                res[cnt] = itemSet;
                cnt++;
            }
            Collections.sort(Arrays.asList(res));
            for(String i : res)
                out1.write(i+"\n");

            out1.flush();
            out1.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
